package com.martin.server.impl.netty;
  
import java.io.*;  
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.util.CharsetUtil;
  
public class WebSocketServerIndexPage {

     public static ChannelBuffer getContent(String webSocketLocation) {
         return ChannelBuffers.copiedBuffer( fetch("com/martin/server/impl/netty/client.html") , CharsetUtil.UTF_8 );
     }

     private static String fetch( final String target ) { 
       System.out.println("feching from CL: " + target );   
       final StringBuffer buf = new StringBuffer();           
       try {                               
            final BufferedReader reader = 
              new BufferedReader(
                new InputStreamReader(
                  WebSocketServerIndexPage.class.
                    getClassLoader().getResourceAsStream(target) 
                )
              );
            if ( reader != null ) {  
            try {  
             String line;
             while ((line = reader.readLine()) != null) {
               buf.append(line).
                   append("\r\n");  
             }
            } catch ( Exception x ) { }
            finally {
             reader.close();  
            }
           } else {
                System.out.println(target+" no found :(");
           }
      } catch ( Exception io ) {
           System.err.println("feching html");
           io.printStackTrace();
      }
        return buf.toString();           
     }  

}
      

